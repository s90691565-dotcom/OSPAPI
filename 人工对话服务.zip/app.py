from flask import Flask, render_template, request, Response
import json, time

app = Flask(__name__)
# 更换模型名称 deepseek-r1
MODEL = "deepseek-r1"
API_KEY = "sk-1p54w6own37s64sk3464.oz64p6316pja64"

user_msg = ""
reply_msg = ""

# 人工控制面板
@app.route("/")
def index():
    return render_template("chat.html", user=user_msg)

# APP上报消息
@app.route("/getuser")
def getuser():
    global user_msg
    m = request.args.get("msg","")
    if m:
        user_msg = m
    return '{"code":200,"msg":"success"}'

# 后端设置回复
@app.route("/set/<txt>")
def setmsg(txt):
    global reply_msg
    reply_msg = txt
    return '{"ok":true}'

# SSE流式输出
@app.route("/v1/chat/completions",methods=["POST"])
def stream_api():
    def stream_data():
        # 逐字推送
        for char in reply_msg:
            chunk = {
                "id":"fake-id",
                "object":"chat.completion.chunk",
                "created":1700000000,
                "model":"deepseek-r1",
                "choices":[{"index":0,"delta":{"content":char},"finish_reason":None}]
            }
            yield f'data: {json.dumps(chunk)}\n\n'
            time.sleep(0.05)
        # 结束分片
        end_chunk = {
            "id":"fake-id",
            "object":"chat.completion.chunk",
            "created":1700000000,
            "model":"deepseek-r1",
            "choices":[{"index":0,"delta":{},"finish_reason":"stop"}]
        }
        yield f'data: {json.dumps(end_chunk)}\n\n'
        yield 'data: [DONE]\n\n'
    return Response(stream_data(), mimetype="text/event-stream")

if __name__ == '__main__':
    app.run(host="0.0.0.0",port=5000,debug=False)

